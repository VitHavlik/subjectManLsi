var UU5 = window.UU5 || {};
UU5.Environment = {"uu_app_oidc_backend_available":true,"uu_app_oidc_backend_grant_call_token_available":true};